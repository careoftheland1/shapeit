import { lazy, Suspense } from "react";
import heroUrl from "./assets/re-corner.png";

const ShelterPage = lazy(() => import("./ShelterPage.jsx"));
const PackagesPage = lazy(() => import("./PackagesPage.jsx"));
const SchoolPage = lazy(() => import("./SchoolPage.jsx"));

const services = [
  ["01", "Buildable plans", "Complete drawing sets, material schedules and details developed for natural construction—not just images of an idea."],
  ["02", "Affordable builds", "Small, deliberate footprints. Simple assemblies. Local earth and lava-based materials that keep costs close to the ground."],
  ["03", "Help along the way", "Site review, sourcing support and construction guidance at the moments when another set of eyes matters."],
];

const shelters = [
  { number: "S—01", name: "The Room", area: "200 sq ft", rooms: "Studio / 1 bath", shape: "room", slug: "the-room" },
  { number: "S—02", name: "The Courtyard", area: "480 sq ft", rooms: "1 bed / 1 bath", shape: "court", slug: "the-courtyard" },
  { number: "S—03", name: "The Long House", area: "720 sq ft", rooms: "2 bed / 1 bath", shape: "long", slug: "the-long-house" },
];

function Plan({ shape }) {
  return <svg className={`plan plan-${shape}`} viewBox="0 0 420 260" aria-hidden="true">
    {shape === "room" && <><rect x="105" y="34" width="210" height="192"/><path d="M105 164h80m45 62v-62h85M185 164v62M230 164h85"/><path className="door" d="M185 180a38 38 0 0 1 38-38"/></>}
    {shape === "court" && <><path d="M58 45h304v170H58zM156 95h108v120H156z"/><path d="M58 95h98m108 0h98M110 95v120m200-120v120"/><path className="door" d="M156 130a35 35 0 0 0-35-35M264 130a35 35 0 0 1 35-35"/></>}
    {shape === "long" && <><rect x="28" y="70" width="364" height="120"/><path d="M128 70v120m98-120v120m78-120v120M28 130h100m98 0h78"/><path className="door" d="M128 150a30 30 0 0 1 30-30M226 150a30 30 0 0 0-30-30"/></>}
  </svg>;
}

function App() {
  if (window.location.pathname.startsWith("/school")) {
    return <Suspense fallback={<div className="page-loading">Opening the school…</div>}><SchoolPage /></Suspense>;
  }
  if (window.location.pathname.startsWith("/packages")) {
    return <Suspense fallback={<div className="page-loading">Loading support…</div>}><PackagesPage /></Suspense>;
  }
  if (window.location.pathname.startsWith("/shelters/")) {
    return <Suspense fallback={<div className="page-loading">Loading shelter…</div>}><ShelterPage /></Suspense>;
  }
  return <main>
    <header className="nav">
      <a className="wordmark" href="#top">shelter&nbsp;&nbsp;&nbsp;on the&nbsp;&nbsp;land</a>
      <nav><a href="#practice">Practice</a><a href="#shelters">Shelters</a><a href="/school/">School</a><a href="/packages/">Support</a></nav>
      <a className="nav-cta" href="#contact">Start a build ↗</a>
    </header>

    <section className="hero" id="top">
      <img src={heroUrl} alt="Warm afternoon light inside a naturally built earthen shelter"/>
      <div className="hero-wash"/>
      <p className="hero-note">Buildable plans for rammed earth<br/>and lavacrete shelters</p>
      <h1>be a<br/>builder</h1>
      <a className="down" href="#process">See how it works <span>↓</span></a>
    </section>

    <section className="manifesto" id="practice">
      <p className="kicker">Shelter on the Land / The practice</p>
      <div>
        <h2>Good shelter can<br/>come from the ground.</h2>
        <p>We design small buildings that ordinary people can understand, afford and make. Our plans turn ancient earthen methods into clear, contemporary systems for life on the land.</p>
      </div>
    </section>

    <section className="services">
      {services.map(([n,title,copy]) => <article key={n}><span>{n}</span><h3>{title}</h3><p>{copy}</p></article>)}
    </section>

    <section className="plans" id="shelters">
      <header><p className="kicker">The shelter collection</p><h2>Plans made<br/>to be built.</h2><p>Each shelter is a complete starting point, adaptable to climate, material and the particulars of your land.</p></header>
      <div className="plan-grid">
        {shelters.map(s => <a className="plan-card" href={`/shelters/${s.slug}/`} key={s.number}>
          <div className="plan-meta"><span>{s.number}</span><span>{s.area}</span></div>
          <Plan shape={s.shape}/>
          <div className="plan-name"><h3>{s.name}</h3><p>{s.rooms}</p><b>↗</b></div>
        </a>)}
      </div>
      <a className="text-link" href="/packages/">Compare support <span>→</span></a>
    </section>

    <section className="process" id="process">
      <p className="kicker">How it works</p>
      <h2>You bring the land.<br/>We bring a place to start.</h2>
      <ol>
        <li><span>01</span><div><h3>Choose a shelter</h3><p>Start with the plan that fits how you live and what the land can hold.</p></div></li>
        <li><span>02</span><div><h3>Make it yours</h3><p>Localize your plan set to your jurisdiction’s codes on your own or with an engineer. We can help adapt siting, material and openings to your climate and place.</p></div></li>
        <li><span>03</span><div><h3>Build with support</h3><p>Use the drawings independently or bring us in for guidance along the way.</p></div></li>
      </ol>
    </section>

    <section className="contact" id="contact">
      <p className="kicker">Plans to build your own shelter</p>
      <h2>Start where<br/>you are.</h2>
      <a href="#shelters">See the collection <span>↗</span></a>
    </section>

    <footer id="about"><a className="wordmark" href="#top">shelter&nbsp;&nbsp;&nbsp;on the&nbsp;&nbsp;land</a><p>Rammed earth · Lavacrete<br/>Small architecture</p><p>Arizona / High desert<br/>hello@onthe.land</p><p>© 2026 Shelter on the Land</p></footer>
  </main>;
}

export default App;
