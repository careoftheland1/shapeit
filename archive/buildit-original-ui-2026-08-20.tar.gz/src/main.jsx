import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import AppAlt from './AppAlt.jsx'

const RootApp = new URLSearchParams(window.location.search).has('alt') ? AppAlt : App

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RootApp />
  </StrictMode>,
)
